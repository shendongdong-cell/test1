package Bean;

public class Count {
    private String count;

	public Count(String count) {
		super();
		this.count = count;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}
    
}
